---
title: "DB設計"
aliases:
  - "DB設計"
---
# 04 DB設計

スナップショット: 2026-07-15 / v0.48（正: `worker/migrations/` と `docs/db-design-v2.md`）

## 3層構成
| 層 | 役割 | 中身 |
|---|---|---|
| localStorage | 高速キャッシュ・端末ローカル | 業務データのミラー＋入出庫（※現状ここだけ＝要D1同期） |
| Durable Object storage | セッション中のライブ状態 | inventory / orders（発注数・2026-07追加） / auditLog(200件) / messages / hostToken / config |
| D1 (SQLite) | 記録の正 | 下表 |

## D1 テーブル（migration 0001〜0009）
| テーブル | 役割 | 補足 |
|---|---|---|
| stores | 店舗・認証・プラン | pin_hash=PBKDF2、plan列（サーバー側プラン管理） |
| auth_tokens | Bearerトークン（30日） | |
| sessions | 棚卸/発注セッション | type列で stock/order 区別 |
| store_history | 完了スナップショット（50件） | session_id列の追加が課題（全件パース排除） |
| inventory_lines | 1品目1行の時系列（分析用） | 10GB天井→R2アーカイブが将来課題 |
| orders | 発注レコード | |
| login_attempts / ip_attempts | レート制限 | フェイルオープン |
| push_subscriptions | プッシュ購読 | |

## localStorage キー（`utils/storageKeys.js` が正・直書き禁止）
- 業務データ（アカウント切替で全消去）: inventory_v1 / inventory_config_v1 / inventory_history_v1 / inventory_orders_v1 / inventory_movements_v1 / inventory_aliases_v1 / inventory_master_v1
- 認証系: _auth_token / _shop_code / _pending_session_v1 / _host_token_<code>
- 端末固有（保持）: _device_id / _device_name

## DB設計v2（将来・設計済み）
- スナップショットのブロブ → inventory_lines 時系列＋R2生データの2層へ
- 完了処理は `POST /sessions/:id/complete` に集約済み（トランザクション化✅）
- 10倍成長時: 組織ごとD1分割（サイロ型）

## ルール
- スキーマ変更は必ず `worker/migrations/` 追加（`scripts/migrate.sh` が未適用のみ適用）
- 新データは「D1永続化の要否」を明示判断（localStorage専用=消えてよいデータのみ）

## 記録すること（今後）
- マイグレーション追加時の目的・ロールバック可否
- データ量の実測（店舗数・inventory_lines行数）→ R2アーカイブ発火判断
